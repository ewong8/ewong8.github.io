'''
CIS 122 Summer 2020 Lab 1 Challenge
Author: Ethan Wong
Credit:
Description: Lab 1 Challenge
'''
#day = Monday        # Assign string to a variable
day = "Monday"        # To assign a string data type to a variable, must use quotation marks

#square = 2 ^ 2      # Perform power operation
square = 2 ** 2      # ^ operation does not work in python, use ** for exponential calculations

#print square        # Output value of a variable
print(square)        # To call the "print" function, must use parentheses

#print(day + square) # Target output is "Monday 4" (without quotation marks)
print(day, square)   # Cannot concatenate strings with integers, use comma to print both values)

